# PacmanBis
## Authors : Lilian Cizeron & Camille Barbarin--Renvoisé & Antoine Chrétin

### How to ?
Binary can be found under release/

Launch with `java -jar Pacman_v1.1.jar`

### Q&A
**Why the console display many NullPointerException ?**

Then, it is because of a method use to display ImageIcon.

Don't worry about it, it is fully under control.
